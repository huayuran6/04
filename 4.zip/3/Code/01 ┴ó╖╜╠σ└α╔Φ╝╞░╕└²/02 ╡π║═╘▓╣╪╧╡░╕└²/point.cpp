#include "point.h"



//���� x ��y
void Point::setX(int x)
{
	m_X = x;
}
void Point::setY(int y)
{
	m_Y = y;
}
//��ȡ x ��y
int Point::getX()
{
	return m_X;
}
int Point::getY()
{
	return m_Y;
}
